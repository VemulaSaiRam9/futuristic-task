function apply(jobTitle) {
    alert(You have applied for the position of ${jobTitle});
}